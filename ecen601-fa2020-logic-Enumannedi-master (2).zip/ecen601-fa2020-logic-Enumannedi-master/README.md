# Logic, Sets, and Functions

This machine problem focuses on programming some logic functions in Python and, subsequently, using these functions to assess the truth values of certain statements.
These functions are also employed to establish equivalence between various logical forms.

## Action Items

* __Complete__: The exercises described in `challenge.ipynb`.
